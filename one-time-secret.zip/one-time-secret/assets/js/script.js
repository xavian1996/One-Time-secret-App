// Small client helpers (no frameworks)
document.addEventListener('DOMContentLoaded', function(){
  // enhance textarea autosize
  var ta = document.querySelector('textarea');
  if (ta){ ta.addEventListener('input', function(){ this.style.height = 'auto'; this.style.height = (this.scrollHeight)+'px'; }); }
});
