<?php
require_once 'helper.php';
$deleted = cleanupExpired();
echo "Deleted: $deleted expired/invalid secret(s).\n";
?>
