<?php
// Configuration
define('SECRETS_DIR', __DIR__ . '/secrets');
// Server-side encryption key (for simple at-rest encryption). Change this to a random string before deploying.
define('ENC_KEY', 'change_this_to_a_random_secret_key_32chars!'); // length matters for AES-256 (32 bytes)

// ========== Utilities ==========
function getBaseUrl() {
    // Try to build a relative-friendly base URL for local servers
    $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $path = rtrim(dirname($_SERVER['PHP_SELF']), '/\\\\') . '/';
    return $proto . $host . $path;
}

function generateToken($length = 8) {
    // length = number of bytes -> hex length is double that
    return bin2hex(random_bytes($length));
}

function ensureSecretsDir() {
    if (!is_dir(SECRETS_DIR)) mkdir(SECRETS_DIR, 0777, true);
    return is_writable(SECRETS_DIR);
}

function encryptMessage($plaintext) {
    $key = substr(hash('sha256', ENC_KEY, true), 0, 32);
    $iv = random_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $ciphertext = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $ciphertext);
}

function decryptMessage($payload) {
    $key = substr(hash('sha256', ENC_KEY, true), 0, 32);
    $decoded = base64_decode($payload);
    $ivlen = openssl_cipher_iv_length('aes-256-cbc');
    $iv = substr($decoded, 0, $ivlen);
    $cipher = substr($decoded, $ivlen);
    return openssl_decrypt($cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
}

// Save a secret. Returns true/false.
function saveSecret($token, $message, $password = '', $expires_at = 0) {
    if (!ensureSecretsDir()) return false;
    $file = SECRETS_DIR . '/' . preg_replace('/[^a-f0-9]/', '', $token) . '.json';
    $data = [
        'message' => encryptMessage($message),
        'password' => $password ? password_hash($password, PASSWORD_DEFAULT) : '',
        'created_at' => time(),
        'expires_at' => (int)$expires_at
    ];
    $json = json_encode($data);
    return (bool) file_put_contents($file, $json);
}

// Load metadata (without destroying). Returns array or false.
function loadSecretMeta($token) {
    $file = SECRETS_DIR . '/' . preg_replace('/[^a-f0-9]/', '', $token) . '.json';
    if (!file_exists($file)) return false;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return false;
    // Check expiration
    if (!empty($data['expires_at']) && time() > $data['expires_at']) {
        // expired -> destroy file
        @unlink($file);
        return false;
    }
    return $data;
}

// Load and destroy (one-time read). Returns data or false.
function loadAndDestroySecret($token) {
    $file = SECRETS_DIR . '/' . preg_replace('/[^a-f0-9]/', '', $token) . '.json';
    if (!file_exists($file)) return false;
    $data = json_decode(file_get_contents($file), true);
    if (!$data) return false;
    if (!empty($data['expires_at']) && time() > $data['expires_at']) {
        @unlink($file);
        return false;
    }
    // Attempt to destroy first to guarantee one-time behavior even if display fails.
    @unlink($file);
    // Decrypt message
    $message = decryptMessage($data['message']);
    $data['message'] = $message === false ? '' : $message;
    return $data;
}

// Destroy without reading (used on failed attempts)
function destroySecret($token) {
    $file = SECRETS_DIR . '/' . preg_replace('/[^a-f0-9]/', '', $token) . '.json';
    if (file_exists($file)) { @unlink($file); return true; }
    return false;
}

// Cleanup old expired secrets (call manually or via cron)
function cleanupExpired() {
    if (!is_dir(SECRETS_DIR)) return 0;
    $files = glob(SECRETS_DIR . '/*.json');
    $deleted = 0;
    foreach ($files as $f) {
        $data = json_decode(file_get_contents($f), true);
        if (!$data) { @unlink($f); $deleted++; continue; }
        if (!empty($data['expires_at']) && time() > $data['expires_at']) {
            @unlink($f); $deleted++;
        }
    }
    return $deleted;
}
?>
