<?php
require_once 'helper.php';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>One-Time Secret</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<main class="wrap">
  <div class="card">
    <h1>One-Time Secret 🔒</h1>
    <p class="lead">Create a secret link that can be opened <strong>only once</strong>.</p>
    <form action="process_secret.php" method="post" id="createForm">
      <label>Secret message</label>
      <textarea name="message" rows="6" required placeholder="Type your secret..."></textarea>

      <div class="row">
        <div class="col">
          <label>Optional password</label>
          <input type="password" name="password" placeholder="Password (optional)">
        </div>
        <div class="col">
          <label>Expiration</label>
          <select name="expire">
            <option value="3600">1 hour</option>
            <option value="86400" selected>1 day</option>
            <option value="604800">1 week</option>
            <option value="0">Never (manual cleanup)</option>
          </select>
        </div>
      </div>

      <div class="actions">
        <button class="btn" type="submit">Create Secret</button>
      </div>
    </form>
    <small class="muted">Runs locally — no database required. Files are stored in <code>/secrets</code>.</small>
  </div>
</main>
<script src="assets/js/script.js"></script>
</body>
</html>
