<?php
require_once 'helper.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$message = trim($_POST['message'] ?? '');
$password = trim($_POST['password'] ?? '');
$expire = (int)($_POST['expire'] ?? 86400);

if ($message === '') {
    die('Message required.');
}

$token = generateToken(10); // 20 hex chars
$expires_at = $expire > 0 ? time() + $expire : 0;

$save = saveSecret($token, $message, $password, $expires_at);

if (!$save) {
    die('Failed to save secret. Check permissions for the secrets folder.');
}

// Use relative link for local servers like KSWeb
require_once 'assets/phpqrcode/qrlib.php';

$link = getBaseUrl() . 'read.php?token=' . $token;

// Generate QR code image (robust: use absolute FS path, check for library and write errors)
$qrWebPath = 'assets/qrcodes/' . $token . '.png';
$qrDir = __DIR__ . '/assets/qrcodes';
$qrFilePath = $qrDir . '/' . $token . '.png';
$qrFile = ''; // web-path used in the HTML (empty if not available)

if (!is_dir($qrDir)) {
    if (!@mkdir($qrDir, 0777, true) && !is_dir($qrDir)) {
        // failed to create directory, skip QR generation
        $qrWebPath = '';
    }
}

if ($qrWebPath !== '') {
    if (class_exists('QRcode') && method_exists('QRcode', 'png')) {
        try {
            // QRcode::png writes to the outfile path when provided
            QRcode::png($link, $qrFilePath, QR_ECLEVEL_L, 5);
            if (file_exists($qrFilePath)) {
                $qrFile = $qrWebPath;
            }
        } catch (Throwable $e) {
            // on any error, fall back to no image (do not die)
            $qrFile = '';
        }
    } else {
        // QR library not available
        $qrFile = '';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secret Created</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<main class="wrap">
  <div class="card">
    <h1>Secret Created ✅</h1>
    <p>Share this link — it will work <strong>only once</strong>:</p>
    <div class="linkbox">
      <input id="secretLink" readonly value="<?php echo htmlspecialchars($link, ENT_QUOTES); ?>">
  
      <button class="btn" onclick="copyLink()">Copy</button>
    </div>

<?php if ($qrFile): ?>
    <div class="qrcode">
      <p>Scan this QR code to open the secret:</p>
      <img src="<?php echo htmlspecialchars($qrFile, ENT_QUOTES); ?>" alt="QR Code" />
    </div>
<?php else: ?>
    <p class="muted">QR code not available (QR library/GD missing or write permission issue). Use the link above.</p>
<?php endif; ?>

    <p class="muted">Don't close this page until you've copied the link.</p>
    <a class="small-link" href="index.php">Create another</a>
  </div>
</main>
<script>
function copyLink(){ const el = document.getElementById('secretLink'); el.select(); document.execCommand('copy'); alert('Link copied to clipboard'); }
</script>
</body>
</html>
