<?php
require_once 'helper.php';

$token = $_GET['token'] ?? '';
if (!$token) {
    http_response_code(400);
    die('Missing token.');
}

// Try to load secret WITHOUT immediately deleting; we will delete after successful read attempt.
$meta = loadSecretMeta($token);
if (!$meta) {
    showError('Invalid or expired secret.');
    exit;
}

// If secret has a password, require it via POST
if ($meta['password']) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $provided = $_POST['password'] ?? '';
        if (!password_verify($provided, $meta['password'])) {
            showError('Wrong password. This secret is now destroyed.');
            // To keep the "one-time" promise, destroy file on wrong password attempt as well.
            destroySecret($token);
            exit;
        }
        // Password correct — read, destroy, and show.
        $data = loadAndDestroySecret($token);
        if (!$data) { showError('Secret not available.'); exit; }
        showSecret($data['message']);
        exit;
    }
    // Show password entry form
    ?>
    <!doctype html>
    <html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Protected Secret</title>
    <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
    <main class="wrap">
      <div class="card">
        <h1>Protected Secret 🔐</h1>
        <p>Please enter the password to view this secret.</p>
        <form method="post">
          <input type="password" name="password" placeholder="Password" required>
          <div class="actions"><button class="btn" type="submit">View Secret</button></div>
        </form>
      </div>
    </main>
    </body>
    </html>
    <?php
    exit;
}

// No password — read and destroy
$data = loadAndDestroySecret($token);
if (!$data) {
    showError('Secret not available or already read.');
    exit;
}
showSecret($data['message']);
exit;

// Helpers to present pages
function showError($msg){ ?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Secret</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><main class="wrap"><div class="card"><h1>Notice</h1><p class="muted"><?php echo htmlspecialchars($msg); ?></p><a class="small-link" href="index.php">Back</a></div></main></body></html>
<?php }

function showSecret($message){ ?>
<!doctype html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Your Secret</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body><main class="wrap"><div class="card"><h1>🔓 Secret</h1><div class="secret"><?php echo nl2br(htmlspecialchars($message)); ?></div><p class="muted">This message was destroyed after viewing.</p><a class="small-link" href="index.php">Create another</a></div></main></body></html>
<?php }
